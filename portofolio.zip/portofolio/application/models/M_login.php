<?php

class M_login extends CI_Model
{
	

	public function cek_data($table, $where){
		$data = $this->db->get_where($table, $where);
		return $data;
	}

	public function cek_akun(){
		$data = $this->db->get('user')->result_array();
		return $data;
	}

	public function insert_user($q_data){
		$data = $this->db->insert('user', $q_data);
		if($data){
			return true;
		}else{
			return false;
		}
	}

	public function edit_user($id){
		$data = $this->db->get_where('user', $id);

		return $data;
	}

	public function update_user($q_data, $where){
		$data = $this->db->update('user', $q_data, $where);

		if($data){
			return true;
		}else{
			return false;
		}
	}

	public function Delete_user( $where){
		$data = $this->db->delete('user', $where);

		if($data){
			return true;
		}else{
			return false;
		}
	}

}