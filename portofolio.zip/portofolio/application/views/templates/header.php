<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

    <link rel="stylesheet" href="<?php echo base_url()?>css/bootstrap.min.css" >
    <link rel = "stylesheet" type = "text/css" href = "<?php echo base_url()?>css/style.css">
	

    <title>Hello, world!</title>
  </head>
  <body>
  	<script src="<?php echo base_url()?>js/jquery-3.3.1.slim.min.js" ></script>
    <script src="<?php echo base_url()?>js/popper.min.js" ></script>
    <script src="<?php echo base_url()?>https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="<?php echo base_url()?>js/bootstrap.min.js" ></script>

		<div id="container">
			<div id="header">	
				<a href=""></a>
				<img src="images/logo.jpg"/>
				<h1 id="perusahaan">PT INDUSTRI KONSTRUKSI</h1>
		</div>