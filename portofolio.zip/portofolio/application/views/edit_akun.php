
	<div style="text-align: center;">
	
	<form method="post" enctype="multipart/form-data" action="<?php echo base_url()?>akun/update_user">	

		<div class="element-form">	
			<span><input type="hidden" name="User_id" value ="<?php echo $akun[0]['User_id']?>"/>
			 </span>

		</div>

		<div class="element-form">
			<label> Nama Lengkap </label>	
			<span><input type="text" name="nama" value ="<?php echo $akun[0]['Nama']?>"/>
			 </span>

		</div>

		<div class="element-form">
			<label> Admin </label>	
			<span>
				<input type="radio" name="admin" value="Yes" /> Yes
				<input type="radio" name="admin" value="No" /> No
			</span>

		</div>

		<div class="element-form">
			<label> Gambar </label>	
			<span>
				<input type="file" name="userfile" class="form-control" size="20" >
			</span>

		</div>
		<img src="<?php echo base_url().'/gambar/'. $akun[0]['Gambar']; ?>" width="100">

		<div class="element-form">
			<label> Username </label>	
			<span><input type="text" name="username" value="<?php echo $akun[0]['Username']?>" />
			 </span>

		</div>

		<div class="element-form">
			<label> Password  </label>
			<span><input type="password" name="password"/></span>

		</div>

		<div class="element-form">
			<span><input type="submit" value="Register"/> 
			 </span>

		</div>

		<div class="element-form">
			
			<a class="kembali" href="<?php echo base_url()?>Akun">Kembali</a>

		</div>

	</form>
</div>