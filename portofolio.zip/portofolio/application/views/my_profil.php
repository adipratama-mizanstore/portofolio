
<div id="bg-page-profile">

	<div id="menu-profile">

		<ul>
			<?php
				if($admin == "Yes"){
			?>

				<li>
					<a href="Akun">Daftar Akun</a>
				</li>

				<li>
					<a href="">Data Pemasok</a>
				</li>

				<li>
					<a href="">Data Produksi</a>
				</li>

				<li>
					<a href="">Katalog</a>
				</li>

			
			
			<?php
				}
			?>
				<li>
  					<a href="#demo" data-toggle="collapse">Laporan Data</a>
  					<div id="demo" class="collapse">
    					<a class="dropdown-item" href=""; ?>">Data Pemasok</a>
      					<a class="dropdown-item" href=""; ?>">Data Produksi</a>
 					 </div>
				</li>
			
				<li >
  					<a href="#demo1" data-toggle="collapse">Grafik</a>
  					<div id="demo1" class="collapse">
    					<a class="dropdown-item" href=""; ?>">Grafik Pemasok</a>
      					<a class="dropdown-item" href=""; ?>">Grafik Produksi</a>
 					 </div>
				</li>
	</div>

	<div id="profile-content">

		
		<CENTER><h3>SELAMAT DATANG</h3></CENTER>
	</div>

</div>