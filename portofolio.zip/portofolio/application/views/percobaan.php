<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<!DOCTYPE html>
<html>
<head>
	<title>	Data Monitoring</title>

	<link rel="stylesheet" href="css/bootstrap.min.css" >
	<link href="<?php echo BASE_URL."css/style.css"; ?>" type="text/css" rel="stylesheet" />  
	<script type="text/javascript" src="chartjs/Chart.js"></script>


</head>
<body>
	<script src="js/jquery-3.3.1.slim.min.js" ></script>
    <script src="js/popper.min.js" ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" ></script>

		<div id="container">
			<div id="header">	
				<a href="<?php echo BASE_URL."index.php?page=login"; ?>"></a>
				<img src="images/logo.jpg"/>
				<h1 id="perusahaan">PT INDUSTRI KONSTRUKSI</h1>

				<div id="menu">
					<div id="user">	
						<?php
							if($id){
								echo "<a>$username</a>, 
										<a href='".BASE_URL."index.php?page=my_profile&module=pesanan&action=list'>My Profile</a>
										<a href='".BASE_URL."Logout.php'>Logout</a>";

							}else{
								echo "<a href='".BASE_URL."index.php?page=login'> LOGIN </a>"; 
							}

						?>
					</div>

					
			</div>
		</div>

		<div id="conten"></div>

			<?php
				$filename = "$page.php";

				if(file_exists($filename)){
					include_once($filename);
				}else{
					echo"maaf, data tidak ada";
				}
			?>


		<div id="footer">
			<p>Copyright Nur Asrofah Sedyo Ningrum </p>
		</div>
	</body>
</html>

 