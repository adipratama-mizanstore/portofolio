<div id="container-user-akses">


	<form action="login/proses_login" method="POST"> <!-- link ke mana -->

		<?php
			$notif = isset($_GET['notif']) ? $_GET['notif'] : false;

			if($notif == true){
				echo "<div class='notif'>Maaf,  data masih kosong </div>";
			}

		?>
		
		<div class="element-form">
			<label> Username </label>	
			<span><input type="text" name="Username" /></span>

		</div>

		<div class="element-form">
			<label> Password  </label>
			<span><input type="password" name="Password"/></span>

		</div>

		<div class="element-form">
			<span><input type="submit" value="Login"/> </span>

		</div>

	</form>

</div> 