<div class="element-form">

	<CENTER>
		
		<h3>DAFTAR AKUN</h3>

	</CENTER>
	<span class="float-left">

	<a href="Halaman">Kembali</a>
	
	</span>
	<span class="float-right">

	<a href="<?php echo base_url()?>Akun/Tambah_user">Tambah Data User</a>
	
	</span>

</div>

<div>
	
		<table class="table-list">
			<tr class='baris-title'>
				<th class='col-id'>NO</th>
				<th class='col-nama'>Nama</th>
				<th class='col-admin'>Admin</th>
				<th class='col-username'>Username</th>
				<th class='col-gambar'>Foto</th>
				<th class='col-aksi'>Aksi</th>
			</tr> 
			<?php foreach( $akun as $akn) :?>
				<tr>
					<td><?=$akn['User_id']?></td>
					<td><?=$akn['Nama']?></td>
					<td><?=$akn['Admin']?></td>
					<td><?=$akn['Username']?></td>
					<td><img src="<?php echo base_url(). '/gambar/'.$akn['Gambar']; ?>" width="10"></td>
					<td>
						<a href="<?php echo base_url()?>Akun/edit_user/<?= $akn['User_id'] ?>">Edit </a>
						<a href="<?php echo base_url()?>Akun/delete_user/<?= $akn['User_id'] ?>">Hapus </a>
					</td>
					
				</tr>
			<?php endforeach;?>
			
		</table>
	
</div>
