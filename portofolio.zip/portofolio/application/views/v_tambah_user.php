
	<div style="text-align: center;">
	<!-- <form action="<?php echo base_url()?>akun/insert_user" method="POST">	 -->
	<form method="post" enctype="multipart/form-data" action="<?php echo base_url()?>akun/insert_user">	

		<div class="element-form">
			<label> Nama Lengkap </label>	
			<span><input type="text" name="nama" />
			 </span>

		</div>

		<div class="element-form">
			<label> Admin </label>	
			<span>
				<input type="radio" name="admin" value="Yes" /> Yes
				<input type="radio" name="admin" value="No" /> No
			</span>

		</div>

		<div class="element-form">
			<label> Gambar </label>	
			<span>
				<input type="file" name="userfile" class="form-control" size="20" required="">
			</span>

		</div>

		<div class="element-form">
			<label> Username </label>	
			<span><input type="text" name="username" />
			 </span>

		</div>

		<div class="element-form">
			<label> Password  </label>
			<span><input type="password" name="password"/></span>

		</div>

		<div class="element-form">
			<span><input type="submit" value="Register"/> 
			 </span>

		</div>

		<div class="element-form">
			
			<a class="kembali" href="<?php echo base_url()?>Akun">Kembali</a>

		</div>

	</form>
</div>