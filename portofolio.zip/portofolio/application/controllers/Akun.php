<?php

/**
 * 
 */
class Akun extends CI_Controller
{
	
	function __construct(){

		parent::__construct();		
		$this->load->model('m_login');
		$this->load->helper('form');
	}


	public function index(){
		$data['akun'] = $this->m_login->cek_akun();

		$this->load->view('templates/header');
		$this->load->view('v_akun', $data);
		
		$this->load->view('templates/footer');
	}

	public function tambah_user(){

		$this->load->view('templates/header');
		$this->load->view('v_tambah_user');
		$this->load->view('templates/footer');
	}

	public function insert_user(){

		$config['upload_path']          = './gambar/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['max_size']             = 10000;
        $config['max_width']            = 10000;
        $config['max_height']           = 10000;

        $data = $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload('userfile')){
            echo "Gagal Tambah";
        }
        else{
            $gambar = $this->upload->data();
            $gambar = $gambar['file_name'];
            $q_data = array(
				'Nama' => $this->input->post('nama'),
				'Admin' => $this->input->post('admin'),
				'Username' => $this->input->post('username'),
				'Password' => $this->input->post('password'),
				'Gambar' => $gambar
			);

			$d_login = $this->m_login->insert_user($q_data);

			if($d_login == 1){
				redirect(base_url('akun'));
			}else{
				echo 'database gagal masuk';
			}
        }
		
		
	}

	public function edit_user($id){

		$where = array(
			'User_id' => $id);

		$data['akun'] = $this->m_login->edit_user($where)->result_array();
	
		$this->load->view('templates/header');
		$this->load->view('edit_akun', $data);
		$this->load->view('templates/footer');
		
		
		
	}

	public function update_user(){
		$user_id = $this->input->post('User_id');

		$config['upload_path']          = './gambar/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['max_size']             = 10000;
        $config['max_width']            = 10000;
        $config['max_height']           = 10000;

        $data = $this->load->library('upload', $config);
        // var_dump($data);die;	
        if ( ! $this->upload->do_upload('userfile')){
            $q_data = array(
				'Nama' => $this->input->post('nama'),
				'Admin' => $this->input->post('admin'),
				'Username' => $this->input->post('username'),
				'Password' => $this->input->post('password')
			);

			$where = array(
				'User_id' => $user_id
			);

			$d_login = $this->m_login->update_user($q_data, $where);

			if($d_login == 1){
				redirect(base_url('akun'));
			}else{
				echo 'database gagal masuk';
			}
        }
        else{

            $gambar = $this->upload->data();
            $gambar = $gambar['file_name'];
            $q_data = array(
				'Nama' => $this->input->post('nama'),
				'Admin' => $this->input->post('admin'),
				'Username' => $this->input->post('username'),
				'Password' => $this->input->post('password'),
				'Gambar' => $gambar
			);
            $where = array(
				'User_id' => $user_id
			);

			$d_login = $this->m_login->update_user($q_data, $where);

			if($d_login == 1){
				redirect(base_url('akun'));
			}else{
				echo 'database gagal masuk';
			}
        }
	}

	public function delete_user($id){

		$where = array('User_id' => $id );
		$this->m_login->delete_user($where);
		redirect(base_url('akun'));
	}
}