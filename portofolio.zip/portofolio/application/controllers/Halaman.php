<?php

/**
 * 
 */
class Halaman extends CI_controller
{
	
	function __construct()
	{
		parent::__construct();
	
		if($this->session->userdata('status') != "login"){
			redirect(base_url("login"));
		}
	}
	public function Index(){
	
		$data['admin'] = $this->session->userdata('admin');

		$this->load->view('templates/header');
		$this->load->view('my_profil', $data);
		
		$this->load->view('templates/footer');
	}
}

?>