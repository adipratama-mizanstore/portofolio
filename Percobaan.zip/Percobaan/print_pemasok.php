<?php
	include("function/koneksi.php");
	

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>CETAK PRINT DATA PEMASOK</title>
</head>
<body>

	<center>

		<h2>DATA LAPORAN BARANG PEMASOK</h2>
		<h3>PT INDUSTRI KONSTRUKSI</h3>

	</center>

	<table border="1" style="width: 100%">
		<tr>
			<th>NO</th>
			<th>Vendor</th>
			<th>Tanggal</th>
			<th>Bulan</th>
			<th>Tahun</th>
			<th>IPB</th>
			<th>Volume</th>
			<th>Uraian</th>

		</tr>
		<?php 
		$no = 1;
		$sql = mysqli_query($koneksi,"SELECT * FROM data_pemasok");
		while($data = mysqli_fetch_array($sql)){
		
		echo "<tr>
			<td>  $no</td>
			<td>  $data[Vendor]</td>
			<td>  $data[Tanggal]</td>
			<td>  $data[Bulan]</td>
			<td>  $data[Tahun]</td>
			<td>  $data[IPB] </td>
			<td>  $data[Volume]</td>
			<td>  $data[Uraian]</td>
		</tr>";
		$no++
		?>
		<?php 

		}

		?>
	</table>

	<script>
		window.print();
	</script>

</body>
</html>