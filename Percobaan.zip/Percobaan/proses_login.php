<?php 

	include_once("function/koneksi.php");
	include_once("function/helper.php");
	
	$username = $_POST['username'];
	$password = $_POST['pass'];
	
	$query = mysqli_query($koneksi, "select * from user where Username='$username' AND Password='$password'");
	
	 
	if(mysqli_num_rows($query) == 0){
		header("location: ". BASE_URL . "index.php?page=login&notif=true");
	}else{
		
		$row = mysqli_fetch_assoc($query);

		session_start();

		$_SESSION['User_id'] = $row['User_id'];
		$_SESSION['Nama'] = $row['Nama'];
		$_SESSION['Username'] = $row['Username'];
		$_SESSION['Password'] = $row['Password'];
		$_SESSION['Admin'] = $row['Admin'];

		header("location: ".BASE_URL."index.php?page=my_profile&module=pesanan&action=list");
	}