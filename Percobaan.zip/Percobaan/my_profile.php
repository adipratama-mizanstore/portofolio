<?php

	if($id){
		$module = isset($_GET['module']) ? $_GET['module'] : false;
		$action = isset($_GET['action']) ? $_GET['action'] : false;
		$mode = isset($_GET['mode']) ? $_GET['mode'] : false;
	}else{

		header("location: ".BASE_URL."index.php?page=login");
	}

?>


<div id="bg-page-profile">

	<div id="menu-profile">

		<ul>
			<?php
				if($Admin == "Yes"){
			?>

				<li>

					<a <?php if($module == "Register") { echo "class='active'";} ?> href="<?php echo BASE_URL."index.php?page=my_profile&module=Register&action=List"; ?>">Daftar Akun</a>
				</li>

				<li>
					<a <?php if($module == "Pemasok") { echo "class='active'";} ?> href="<?php echo BASE_URL."index.php?page=my_profile&module=Pemasok&action=form"; ?>">Data Pemasok</a>
				</li>

				<li>
					<a <?php if($module == "Produksi") { echo "class='active'";} ?>href="<?php echo BASE_URL."index.php?page=my_profile&module=Produksi&action=form"; ?>">Data Produksi</a>
				</li>

				<li>
					<a <?php if($module == "Katalog") { echo "class='active'";} ?>href="<?php echo BASE_URL."index.php?page=my_profile&module=Katalog&action=List"; ?>">Katalog</a>
				</li>

			
			
			<?php
				}
			?>
				<li <?php if($module == "Laporan") { echo "class='active'";} ?>>
  					<a href="#demo" data-toggle="collapse">Laporan Data</a>
  					<div id="demo" class="collapse">
    					<a class="dropdown-item" href="<?php echo BASE_URL."index.php?page=my_profile&module=Laporan&action=pemasok"; ?>">Data Pemasok</a>
      					<a class="dropdown-item" href="<?php echo BASE_URL."index.php?page=my_profile&module=Laporan&action=Produksi"; ?>">Data Produksi</a>
 					 </div>
				</li>
			
				<li <?php if($module == "Grafik") { echo "class='active'";} ?>>
  					<a href="#demo1" data-toggle="collapse">Grafik</a>
  					<div id="demo1" class="collapse">
    					<a class="dropdown-item" href="<?php echo BASE_URL."index.php?page=my_profile&module=Grafik&action=pemasok"; ?>">Grafik Pemasok</a>
      					<a class="dropdown-item" href="<?php echo BASE_URL."index.php?page=my_profile&module=Grafik&action=Produksi"; ?>">Grafik Produksi</a>
 					 </div>
				</li>
	</div>

	<div id="profile-content">
		<?php

		$file = "module/$module/$action.php";
		if(file_exists($file)){

			include_once($file);
		}else{

			echo "<CENTER><h3>SELAMAT DATANG</h3></CENTER>";
		}



		?>
		

	</div>

</div>