<?php
   $server  = "localhost";
   $username  = "root";
   $password  = "123456";
   $database  = "perusahaan";
  
   $koneksi = mysqli_connect($server, $username, $password, $database) or die("koneksi gagal");
   
?>