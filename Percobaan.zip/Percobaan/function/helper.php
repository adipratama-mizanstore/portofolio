<?php

	define("BASE_URL", "http://localhost:8383/Percobaan/");