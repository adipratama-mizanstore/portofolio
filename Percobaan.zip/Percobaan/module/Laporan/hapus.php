<?php
include_once("../../function/koneksi.php");

 $satu = $_GET['Id'];

 
 $result1 = mysqli_query($koneksi, "delete from data_pemasok where Id='$satu'");
 header("location:".BASE_URL."index.php?page=my_profile&module=Laporan&action=pemasok");

?>