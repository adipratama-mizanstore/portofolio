<?php

	include_once("function/koneksi.php");
	include_once("function/helper.php");

?>

<head>

	<head>

		<title>CETAK PRINT DATA PEMASOK</title>
    
	</head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

</head>

<body>
  <CENTER>    
    <H3>Laporan Pemasok</H3>
  </CENTER>

<br>

<form method ='POST' action="">

	
	Cari  : <input type="text" name="cari">
	<input type="submit" value="Cari">

	<select name="list">
    	<option value="vendor">Pemasok</option>
    	<option value="ipb">IPB</option>
    	<option value="bulan">Bulan</option>
    	<option value="uraian">Uraian</option>
  	</select>

</form>

<br>

<form action="hapus.php" method="POST" >
<table border="1">
	<tr class='baris-title'>
		<th class='col-no'> No </th>
        <th class='col-Pemasok'>Pemasok</th>
        <th class='col-tgl'>Tanggal</th>
        <th class='col-bln'>Bulan</th>
        <th class='col-thn'>Tahun</th>
        <th class='col-ipb'>IPB</th>
        <th class='col-vol'>Volume</th>
        <th class='col-urai'>Uraian</th>
        <th class='col-action'>Pilih</th>
      </tr>

     <?php
	
	
	 if (isset($_POST['cari'])) {
	 	$cari=$_POST['cari'];
	 	$kolom=$_POST['list'];

	  	$queryTabel = mysqli_query($koneksi, "SELECT * FROM data_pemasok WHERE $kolom like	'%".$cari."%' ");

   	}else{

	    $queryTabel = mysqli_query($koneksi, "SELECT * FROM data_pemasok");
	}
	$no =1;
   	while($row=mysqli_fetch_array($queryTabel)){
   	 	 $row['Id'];
   	?>

      <tr>
      	  <td><?php echo $no++ ; ?></td>
          <td><?php echo $row['Vendor']; ?></td>
          <td><?php echo $row['Tanggal'] ?></td>
          <td><?php echo $row['Bulan'] ?></td>
          <td><?php echo $row['Tahun'] ?></td>
          <td><?php echo $row['IPB']; ?></td>
          <td><?php echo $row['Volume']; ?></td>
          <td><?php echo $row['Uraian']; ?></td>
          <td>
          	<a href="<?php echo BASE_URL."index.php?page=my_profile&module=Laporan&action=hapus_pemasok&Id=".$row['Id'].";"?>">| Hapus |</a>
          	<a href="<?php echo BASE_URL."index.php?page=my_profile&module=Pemasok&action=form&Id=".$row['Id'].";"?>"> Edit |</a>
          </td>
        </tr>
     


     <?php } ?>

 </table>

 </form>

<br>

  
<form action="<?php echo BASE_URL."print_pemasok.php"; ?>">
<center>
    <div class="element-form">
        <input type="submit" value="CETAK" class="tombol" >
    </div>
</center>
</form>
</body>