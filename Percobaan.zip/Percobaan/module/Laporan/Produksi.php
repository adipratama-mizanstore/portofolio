<?php

	include("function/koneksi.php");
?>

<head>

	<head>
		<title>CETAK PRINT DATA PRODUKSI</title>
	</head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
</head>

<body>

  <CENTER>    
    <H3>Laporan Produksi</H3>
  </CENTER>


<br>

<form method ='POST' action=''>


	Cari  : <input type="text" name="cari">
	<input type="submit" value="Cari">
	
	<select name="list">
 		<option value="projek">Projek</option>
 		<option value="bulan">Bulan</option>
 		<option value="rencana">Rencana</option>
 		<option value="realisasi">Realisasi</option>
	</select>

</form>

<br>

<table border="1" class="projek">

  <tr class='baris-title'>
        <th class='col-projek'>Projek</th>
  </tr>

     <?php
  
  
   if (isset($_POST['cari'])) {
    $cari=$_POST['cari'];
    $kolom=$_POST['list'];


      $queryTabel = mysqli_query($koneksi, "SELECT distinct Projek FROM data_produksi WHERE $kolom like '%".$cari."%' ");

    }else{

      $queryTabel = mysqli_query($koneksi, "SELECT distinct Projek FROM data_produksi");
     
    }

      while($row=mysqli_fetch_array($queryTabel)){
      
    ?>

      <tr>
          <td><?php echo $row['Projek'] ?></th>
      </tr>

    <?php } ?>

 </table>

 <br>

<form action="hapus.php" method="POST" >

<table border="1" class="Kode_produk">

	<tr class='baris-title'>
		    <th class='col-no'> No </th>
        <th class='col-tgl'>Tanggal</th>
        <th class='col-bln'>Bulan</th>
        <th class='col-thn'>Tahun</th>
        <th class='col-kode'>Kode Produk</th>
        <th class='col-rencana'>Rencana</th>
        <th class='col-realisasi'>Realisasi</th>
        <th class='col-action'>Pilih</th>
  </tr>

     <?php
	
	
	 if (isset($_POST['cari'])) {
	 	$cari=$_POST['cari'];
		$kolom=$_POST['list'];

 
	  	$queryTabel = mysqli_query($koneksi, "SELECT * FROM data_produksi WHERE $kolom like	'%".$cari."%' ");

   	}else{

	    $queryTabel = mysqli_query($koneksi, "SELECT * FROM data_produksi");
     
    }
     $no =1;
      while($row=mysqli_fetch_array($queryTabel)){
            $row['Id']
    ?>

      <tr>
          <td><?php echo $no++ ?></th>
          <td><?php echo $row['Tanggal'] ?></th>
          <td><?php echo $row['Bulan'] ?></th>
          <td><?php echo $row['Tahun'] ?></th>
          <td><?php echo $row['Kode_produk'] ?></th>
          <td><?php echo $row['Rencana'] ?></th>
          <td><?php echo $row['Realisasi'] ?></th>
          <td>
            <a href="<?php echo BASE_URL."index.php?page=my_profile&module=Laporan&action=hapus_produksi&Id=".$row['Id'].";"?>">| Hapus |</a>
            <a href="<?php echo BASE_URL."index.php?page=my_profile&module=Produksi&action=form&Id=".$row['Id'].";"?>"> Edit |</a>
          </td>  
      </tr>

    <?php } ?>

 </table>

</form>

 <br>
<form action="<?php echo BASE_URL."print_produksi.php"; ?>">
<center>
    <div class="element-form">
        <input type="submit" value="CETAK" class="tombol" >
    </div>
</center>
</form></body>