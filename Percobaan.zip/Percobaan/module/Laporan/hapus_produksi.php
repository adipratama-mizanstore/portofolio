<?php
include_once("../../function/koneksi.php");

 $satu = $_GET['Id'];

 
 $result1 = mysqli_query($koneksi, "delete from data_produksi where Id='$satu'");
 $result2 = mysqli_query($koneksi, "delete from kode_produksi where Id='$satu'");
 $result3 = mysqli_query($koneksi, "delete from projek where Id='$satu'");
 header("location:".BASE_URL."index.php?page=my_profile&module=Laporan&action=produksi");

?>