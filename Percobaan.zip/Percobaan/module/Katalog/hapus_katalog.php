<?php
include_once("../../function/koneksi.php");

 $satu = $_GET['id_katalog'];

 
 $result1 = mysqli_query($koneksi, "delete from katalog where id_katalog='$satu'");
 header("location:".BASE_URL."index.php?page=my_profile&module=katalog&action=list");


?>