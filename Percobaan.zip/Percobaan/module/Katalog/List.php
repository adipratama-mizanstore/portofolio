<div class="element-form">

	<CENTER>
		
		<h3>Katalog Material</h3>

	</CENTER>
	<span class="float-right">

	<a href="<?php echo BASE_URL."index.php?page=my_profile&module=Katalog&action=form"; ?>">Tambah Katalog</a>
	
	</span>
</div>

<form action="hapus_katalog.php" method="POST" >
<table border="1">
	<tr class='baris-title'>
		<th class='col-no'> No </th>
        <th class='col-material'>Material</th>
        <th class='col-tgl'>Satuan</th>
        <th class='col-harga'>Harga</th>
        <th class='col-pilij'>Pilih</th>
      </tr>

     <?php
	$queryTabel = mysqli_query($koneksi, "SELECT * FROM Katalog ");
	
	 if (mysqli_num_rows($queryTabel) == 0) {
		echo"<h3> saat ini belum ada nama terdaftar</h3>";	 	

	  	

   	}else{

	$no =1;
   	while($row=mysqli_fetch_array($queryTabel)){
   	 	 $row['id_katalog'];
   	?>

      <tr>
      	  <td><?php echo $no++ ; ?></td>
          <td><?php echo $row['Material']; ?></td>
          <td><?php echo $row['Satuan'] ?></td>
          <td><?php echo $row['Harga'] ?></td>
          <td>
          	<a href="<?php echo BASE_URL."index.php?page=my_profile&module=Katalog&action=hapus_katalog&Id=".$row['id_katalog'].";"?>">| Hapus |</a>
          	<a href="<?php echo BASE_URL."index.php?page=my_profile&module=Katalog&action=form&Id=".$row['id_katalog'].";"?>"> Edit |</a>
          </td>
        </tr>
     


     <?php
     }
   } ?>

 </table>

 </form>