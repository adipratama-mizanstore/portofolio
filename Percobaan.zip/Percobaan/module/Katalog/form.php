
 <?php
  $id_katalog = isset($_GET['id_katalog']) ? $_GET['id_katalog'] : false;
  $material ="";
  $satuan = "";
  $harga ="";
  $Button = "Simpan";

  if ($kategori_id) {
    $queryKategori = mysqli_query($koneksi, "SELECT * FROM katalog where id_katalog ='$id_katalog'");
    $row = mysqli_fetch_assoc($queryKategori);

    $material = $row['Material'];
    $satuan = $row['Satuan'];
    $harga = $row['Harga'];
    $Button = "Ubah";


  }
?>



  <form action="<?php echo BASE_URL."module/Katalog/action.php"; ?>" method="POST">



    <div class="element-form">
      <label> Material </label> 
      <span><input type="text" name="Material"  value="<?php echo $material; ?>"/>
       </span>

    </div>

    <div class="element-form">
      <label> Satuan </label>  
      <select name="Satuan"  value="<?php echo $satuan; ?>">

        <option value="cm">cm</option>
        <option value="m2">m2</option>
        <option value="kg">kg</option>
        <option value="gram">gram</option>

      </select>

    </div>

    <div class="element-form">
      <label> Harga </label> 
      <span><input type="text" name="Harga"  value="<?php echo $harga; ?>"/>
       </span>

    </div>

    <div class="element-form">
      <span><input type="submit" value="<?php echo $Button; ?>"/> 
       </span>

    </div>

    <div class="element-form">
      
      <a class="kembali" href="<?php echo BASE_URL."index.php?page=my_profile&module=Katalog&action=List"; ?>">Kembali</a>

    </div>

  </form>
