<?php
	include_once("../../function/koneksi.php");
	include_once("../../function/helper.php");

	$material = $_POST['Material'];
	$satuan = $_POST['Satuan'];
	$harga = $_POST['Harga'];

	
	if(empty($material) or empty($satuan) or empty($harga) ){
		echo "Data Belum Lengkap";
		header("location: ".BASE_URL."index.php?page=my_profile&module=Katalog&action=form");
	}else{
		mysqli_query($koneksi, "INSERT INTO katalog (Material, Satuan, Harga) VALUES ( '$material', '$satuan', '$harga')");

		echo "Data Telah Berhasil";
		
		header("location: ".BASE_URL."index.php?page=my_profile&module=Katalog&action=list");

	} 