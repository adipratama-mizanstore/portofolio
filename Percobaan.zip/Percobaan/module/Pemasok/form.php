<?php
	$kategori_id = isset($_GET['Id']) ? $_GET['Id'] : false;
	$Pemasok ="";
	$Tanggal = "";
	$Bulan12 ="";
	$Tahun = "";
	$IPB = "";
	$Volume ="";
	$Uraian = "";
	$Button = "Simpan";

	if ($kategori_id) {
		$queryKategori = mysqli_query($koneksi, "SELECT * FROM data_pemasok where Id ='$kategori_id'");
		$row = mysqli_fetch_assoc($queryKategori);

		$Pemasok = $row['Vendor'];
		$Tanggal = $row['Tanggal'];
		$Bulan12 = $row['Bulan'];
		$Tahun = $row['Tahun'];
		$IPB = $row['IPB'];
		$Volume = $row['Volume'];
		$Uraian = $row['Uraian'];
		$Button = "Ubah";


	}
?>

<form action="<?php echo BASE_URL."module/Pemasok/action.php?Id=$kategori_id"; ?>" method="POST">


<div class="element-form">

	<CENTER>
		<h3> INPUT DATA PEMASOK </h3>
	</CENTER>
	
</div>

<CENTER>
<div class="element-form">
	<label> Pemasok </label>	
	<span><input type="text" name="Pemasok" value="<?php echo $Pemasok; ?>" /> 
	</span>

</div>

<div class="element-form">
	<div class="col-md-6">
	<label> Tanggal </label>	
	<span><input type="text" name="Tanggal" value="<?php echo $Tanggal; ?>" />
	</span>
	</div>

	<div class="col-md-6">
	<label> Bulan </label>
	<select name="Bulan12" value="<?php echo $Bulan12; ?>">

    	<option value="Januari">Januari</option>
    	<option value="Februari">Februari</option>
    	<option value="Maret">Maret</option>
    	<option value="April">April</option>
    	<option value="Mei">Mei</option>
    	<option value="Juni">Juni</option>
    	<option value="Juli">Juli</option>
    	<option value="Agustus">Agustus</option>
    	<option value="September">September</option>
    	<option value="Oktober">Oktober</option>
    	<option value="November">November</option>
    	<option value="Desember">Desember</option>

  	</select>
 	 </div>

 	 <div class="col-md-6">
	<label> Tahun </label>	
	<span><input type="text" name="Tahun" value="<?php echo $Tahun; ?>" />
	</span>

</div>

<div class="element-form">
	<label> IPB </label>	
	<span><input type="text" name="IPB" value="<?php echo $IPB; ?>"/>
	</span>

</div>

<div class="element-form">
	<label> Volume </label>	
	<span><input type="text" name="Volume" value="<?php echo $Volume; ?>"/>
	</span>

</div>

<div class="element-form">

	<label> Uraian </label>	
	<span><input type="text" name="Uraian" value="<?php echo $Uraian; ?>"/>
	</span>

</div>

<div class="element-form">
	<span><input type="submit" name="Button" value="<?php echo $Button; ?>" />
	</span>

</div>
</CENTER>



</form>