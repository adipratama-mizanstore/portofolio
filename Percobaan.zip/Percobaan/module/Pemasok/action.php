<?php

	include_once("../../function/koneksi.php");
	include_once("../../function/helper.php");

	
	$pemasok = $_POST['Pemasok'];
	$tanggal = $_POST['Tanggal'];
	$bulan = $_POST['Bulan12'];
	$tahun = $_POST['Tahun'];
	$IPB = $_POST['IPB'];
	$volume = $_POST['Volume'];
	$uraian = $_POST['Uraian'];
	$button = $_POST['Button'];

	if ($button == "Simpan") {

		mysqli_query($koneksi, "INSERT INTO  data_pemasok (Vendor, Tanggal, Bulan, Tahun, IPB, Volume, Uraian) VALUES ('$pemasok', $tanggal, '$bulan', '$tahun', '$IPB', '$volume', '$uraian')");

		header("location:".BASE_URL."index.php?page=my_profile&module=Pemasok&action=form");

	}else if ($button == "Ubah") {
		$adi = $_GET['Id'];

		mysqli_query($koneksi, "UPDATE data_pemasok set Vendor = '$pemasok',
														Tanggal = '$tanggal',
														Bulan = '$bulan',
														Tahun = '$tahun',
														IPB = '$IPB',
														Volume = '$volume',
														Uraian = '$uraian' WHERE Id='$adi'");

		header("location:".BASE_URL."index.php?page=my_profile&module=Laporan&action=pemasok");

	}
	


?>