<?php 
   include("function/koneksi.php");

?>


<!DOCTYPE html>

   
<html>
<head>
   
   <title>Belajarphp.net - ChartJS</title>
        <script src="Chart.bundle.js"></script>
 
        <style type="text/css">
            .container {
                width: 50%;
                margin: 15px auto;
            }
        </style>
</head>


<body>

   <center>
      <h2>Grafik Data Produksi</h2>
   </center>

   <div style="width: 800px;margin: 0px auto;">
      <canvas id="myChart"></canvas>
   </div>

   <br/>
   <br/>


  
   
    <?php
          $Tanggal = mysqli_query($koneksi, "SELECT Tanggal FROM data_produksi WHERE  Tahun >= 2000  order by Bulan asc");
          $Rencana = mysqli_query($koneksi, "SELECT Rencana FROM data_produksi WHERE Tahun >= 2000 order by Bulan asc");
       
   ?>
   
   <script>

 
      var ctx = document.getElementById("myChart").getContext('2d');
      var myChart = new Chart(ctx, {
         type: 'line',
         data: {
            labels: [<?php while ($b = mysqli_fetch_array($Tanggal)) { echo '"' . $b['Tanggal'] . '",';}?> ],
            datasets: [{
               label: '',
               data: [<?php while ($p = mysqli_fetch_array($Rencana)) { echo '"' . $p['Rencana'] . '",';}?>],
               backgroundColor: [
              'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)',
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)'
               ],
               borderColor: [
               'rgba(255,99,132,1)',
                                'rgba(54, 162, 235, 1)',
                                'rgba(255, 206, 86, 1)',
                                'rgba(75, 192, 192, 1)',
                                'rgba(153, 102, 255, 1)',
                                'rgba(255, 159, 64, 1)',
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)'
               ],
               borderWidth: 1
            }]
         },
         options: {
            scales: {
               yAxes: [{
                  ticks: {
                     beginAtZero:true
                  }
               }]
            }
         }
      });



   </script>


 <table border="1">
      <thead>
         <tr>
            <th>No</th>
            <th>Tanggal</th>
            <th>Bulan</th>
            <th>Rencana</th>
         </tr>
      </thead>
      <tbody>
         <?php 
         $no = 1;
         $data = mysqli_query($koneksi,"select * from data_produksi order by Bulan asc");
         while($d=mysqli_fetch_array($data)){
            ?>
            <tr>
               <td><?php echo $no++; ?></td>
               <td><?php echo $d['Tanggal']; ?></td>
                <td><?php echo $d['Bulan']; ?></td>
               <td><?php echo $d['Rencana']; ?></td>
            </tr>
            <?php 
         }
         ?>
      </tbody>
   </table>
   
</body>
</html>

