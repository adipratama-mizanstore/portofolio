<?php
	$kategori_id = isset($_GET['Id']) ? $_GET['Id'] : false;
	$Projek ="";
	$Tanggal = "";
	$Bulan12 ="";
	$Tahun = "";
	$Kode = "";
	$Rencana ="";
	$Realisasi = "";
	$Button = "Simpan";

	if ($kategori_id) {
		$queryKategori = mysqli_query($koneksi, "SELECT * FROM data_produksi where Id ='$kategori_id'");
		$row = mysqli_fetch_assoc($queryKategori);

		$Projek = $row['Projek'];
		$Tanggal = $row['Tanggal'];
		$Bulan12 = $row['Bulan'];
		$Tahun = $row['Tahun'];
		$Kode = $row['Kode_produk'];
		$Rencana = $row['Rencana'];
		$Realisasi = $row['Realisasi'];
		$Button = "Ubah";


	}
?>
<form action="<?php echo BASE_URL."module/produksi/action.php?Id=$kategori_id"; ?>" method="POST">

<CENTER>
<div class="element-form">
	
		
		<h3> INPUT DATA PRODUKSI </h3>

</div>
<div class="element-form">
	<label> Project </label>	
	<span><input type="text" name="project" value="<?php echo $Projek; ?>" />
	</span>

</div>

<div class="element-form">
	<label> Tanggal </label>	
	<span><input type="text" name="Tanggal" value="<?php echo $Tanggal; ?>"/>
	</span>

	<label> Bulan </label>
	<select name="Bulan12" value="<?php echo $Bulan; ?>">

    	<option value="Januari">Januari</option>
    	<option value="Februari">Februari</option>
    	<option value="Maret">Maret</option>
    	<option value="April">April</option>
    	<option value="Mei">Mei</option>
    	<option value="Juni">Juni</option>
    	<option value="Juli">Juli</option>
    	<option value="Agustus">Agustus</option>
    	<option value="September">September</option>
    	<option value="Oktober">Oktober</option>
    	<option value="November">November</option>
    	<option value="Desember">Desember</option>

  	</select>


	<label> Tahun </label>	
	<span><input type="text" name="Tahun" value="<?php echo $Tahun; ?>"/>
	</span>

</div>

<div class="element-form">
	<label> Kode Produk </label>	
	<span><input type="text" name="Kode" value="<?php echo $Kode; ?>"/>
	</span>

</div>

<div class="element-form">
	<label> Rencana Kumulatif Produksi </label>	
	<span><input type="text" name="Rencana" value="<?php echo $Rencana; ?>"/>
	</span>

</div>

<div class="element-form">

	<label> Realisasi Kumulatif Produksi </label>	
	<span><input type="text" name="Realisasi" value="<?php echo $Realisasi; ?>"/>
	</span>

</div>

<div class="element-form">	
	<span><input type="submit" name="Button" value="<?php echo $Button; ?>" />
	</span>

</div>
<CENTER>




</form>