<?php

	include_once("../../function/koneksi.php");
	include_once("../../function/helper.php");

	$projek = $_POST['project'];
	$tanggal = $_POST['Tanggal'];
	$bulan = $_POST['Bulan12'];
	$tahun = $_POST['Tahun'];
	$kode = $_POST['Kode'];
	$rencana = $_POST['Rencana'];
	$realisasi = $_POST['Realisasi'];
	$button = $_POST['Button'];

	if ($button == "Simpan") {
	$data_produksi = mysqli_query($koneksi, "INSERT INTO  data_produksi (Projek, Tanggal, Bulan, Tahun, kode_produk, Rencana, Realisasi) VALUES ('$projek', '$tanggal', '$bulan', '$tahun', '$kode', '$rencana', '$realisasi')");

	$kode_produk = mysqli_query($koneksi, "INSERT INTO  kode_produksi VALUES ('$kode', '$tanggal', '$bulan', '$tahun')");

	$Projek = mysqli_query($koneksi, "INSERT INTO  projek VALUES ('$tanggal', '$bulan', '$tahun', '$projek')");

	header("location: ".BASE_URL."index.php?page=my_profile&module=Produksi&action=form");
	}else if ($button == "Ubah") {

		$Id = $_GET['Id'];

		mysqli_query($koneksi, "UPDATE kode_produksi set kode_produk = '$kode',
														Tanggal = '$tanggal',
														Bulan = '$bulan',
														Tahun = '$tahun' WHERE Id='$Id'");

		mysqli_query($koneksi, "UPDATE data_produksi set Projek = '$projek',
														Tanggal = '$tanggal',
														Bulan = '$bulan',
														Tahun = '$tahun',
														kode_produk = '$kode',
														rencana = '$rencana',
														realisasi = '$realisasi' WHERE Id='$Id'");
		mysqli_query($koneksi, "UPDATE projek set Projek =Tanggal = '$tanggal',
														Bulan = '$bulan',
														Tahun = '$tahun',
														Projek = '$projek' WHERE Id='$Id'");

		header("location:".BASE_URL."index.php?page=my_profile&module=Laporan&action=produksi");

	}
?>


