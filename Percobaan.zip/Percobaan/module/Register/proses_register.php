<?php
	include_once("../../function/koneksi.php");
	include_once("../../function/helper.php");

	$nama = $_POST['nama'];
	$admin = $_POST['admin'];
	$username = $_POST['username'];
	$password = $_POST['password'];

	
	if(empty($nama) or empty($admin) or empty($username) or empty($password)){
		header("location: ".BASE_URL."index.php?page=my_profile&module=Register&action=form");
	}else{
	mysqli_query($koneksi, "INSERT INTO user (Nama, Admin, Username, Password) VALUES ( '$nama', '$admin', '$username', '$password')");

	} 