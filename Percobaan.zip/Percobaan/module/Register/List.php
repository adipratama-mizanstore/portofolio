<div class="element-form">

	<CENTER>
		
		<h3>DAFTAR AKUN</h3>

	</CENTER>
	<span class="float-right">

	<a href="<?php echo BASE_URL."index.php?page=my_profile&module=Register&action=form"; ?>">Tambah Data User</a>
	
	</span>
</div>

<?php

	$queryTabel = mysqli_query($koneksi, "SELECT * FROM user");

	if(mysqli_num_rows($queryTabel) == 0) {
		echo"<h3> saat ini belum ada nama terdaftar</h3>";

	}else{

		echo"<table class='table-list'>";

		echo "<tr class='baris-title'>
				<th class='col-id'>NO</th>
				<th class='col-nama'>Nama</th>
				<th class='col-admin'>Admin</th>
				<th class='col-username'>Username</th>
			</tr>";

		
		while($row=mysqli_fetch_assoc($queryTabel)){

			echo"<tr>
					<td>$row[User_id]</td>
					<td>$row[Nama]</td>
					<td>$row[Admin]</td>
					<td>$row[Username]</td>
				</tr>";

		}

		echo"</table>";

		}

?>