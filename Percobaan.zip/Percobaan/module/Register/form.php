
	<form action="<?php echo BASE_URL."module/Register/action.php"; ?>" method="POST">

		<?php
			$notif = isset($_GET['notif']) ? $_GET['notif'] : false;
			$nama = isset($_GET['nama']) ? $_GET['nama'] : false;
			$admin = isset($_GET['admin']) ? $_GET['admin'] : false;
			$username = isset($_GET['username']) ? $_GET['username'] : false;
			$password = isset($_GET['password']) ? $_GET['password'] : false;

			if($notif == "require"){
				echo "<div class='notif'>Maaf data belum diisi </div>";
			}

		?>
		

		<div class="element-form">
			<label> Nama Lengkap </label>	
			<span><input type="text" name="nama" />
			 </span>

		</div>

		<div class="element-form">
			<label> Admin </label>	
			<span>
				<input type="radio" name="admin" value="Yes" /> Yes
				<input type="radio" name="admin" value="No" /> No
			</span>

		</div>

		<div class="element-form">
			<label> Username </label>	
			<span><input type="text" name="username" />
			 </span>

		</div>

		<div class="element-form">
			<label> Password  </label>
			<span><input type="password" name="password"/></span>

		</div>

		<div class="element-form">
			<span><input type="submit" value="Register"/> 
			 </span>

		</div>

		<div class="element-form">
			
			<a class="kembali" href="<?php echo BASE_URL."index.php?page=my_profile&module=Register&action=List"; ?>">Kembali</a>

		</div>

	</form>
