<?php
	include("function/koneksi.php");
	

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>CETAK PRINT DATA PRODUKSI</title>
</head>
<body>

	<center>

		<h2>DATA LAPORAN BARANG PRODUKSI</h2>
		<h3>PT INDUSTRI KONSTRUKSI</h3>

	</center>

	<table border="1" style="width: 100%">
		<tr>
			<th>Id</th>
			<th>Projek</th>
			<th>Tanggal</th>
			<th>Bulan</th>
			<th>Tahun</th>
			<th>Kode_produk</th>
			<th>Rencana</th>
			<th>Realisasi</th>

		</tr>
		<?php 
		$no = 1;
		$sql = mysqli_query($koneksi,"SELECT * FROM data_produksi");
		while($data = mysqli_fetch_array($sql)){
		
		?>
		<tr>
			<td><?php echo $no++ ?></td>
			<td><?php echo $data['Projek']; ?></td>
			<td><?php echo $data['Tanggal']; ?></td>
			<td><?php echo $data['Bulan']; ?></td>
			<td><?php echo $data['Tahun']; ?></td>
			<td><?php echo $data['Kode_produk']; ?></td>
			<td><?php echo $data['Rencana']; ?></td>
			<td><?php echo $data['Realisasi']; ?></td>
		</tr>

		<?php 

		}
		?>
	</table>

	<script>
		window.print();
	</script>

</body>
</html>