<?php
		
	if($id){
		header("location: ".BASE_URL);
	}

?>

<div id="container-user-akses">


	<form action="<?php echo BASE_URL."proses_login.php"; ?>" method="POST">

		<?php
			$notif = isset($_GET['notif']) ? $_GET['notif'] : false;

			if($notif == true){
				echo "<div class='notif'>Maaf,  data masih kosong </div>";
			}

		?>
		
		<div class="element-form">
			<label> Username </label>	
			<span><input type="text" name="username" /></span>

		</div>

		<div class="element-form">
			<label> Password  </label>
			<span><input type="password" name="pass"/></span>

		</div>

		<div class="element-form">
			<span><input type="submit" value="Login"/> </span>

		</div>

	</form>

</div> 